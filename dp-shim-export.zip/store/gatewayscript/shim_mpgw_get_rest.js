console.info("Starting REST to JSON route");

console.info(`content of contentID Var: ${sm.getVar('context/POC/contentID')}`);
