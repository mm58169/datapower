console.info("Starting ISP POC Demo");

session.input.readAsBuffer(function (error, bufferObject) {

      session.input.readAsXML(function (error, nodeList) {

         session.output.write(`
          <?xml version="1.0"?>
            <soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope/"soap:encodingStyle="http://www.w3.org/2003/05/soap-encoding">
            <soap:Header></soap:Header>
            <soap:Body>`);

         session.output.write(nodeList);

         session.output.write(`</soap:Body></soap:Envelope>`);
      });

});

console.info("POC SOAP wrapping complete...");
